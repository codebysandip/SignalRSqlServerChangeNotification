﻿namespace DemoCRM.Web
{
    internal class CampaignRepository
    {
    }
}